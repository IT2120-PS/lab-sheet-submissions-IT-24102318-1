getwd
setwd("C:/Users/ASUS/Desktop/IT24102318")

##question 01
## i - Binomial Distribution
## random variable x has Binomial distribution with n=50 and p=0,85
1-pbinom(46,50,0.85,lower.tail = TRUE)
 
##question 02
## i - X = number of calls in one hour
## ii - Poission distribution
## random variable x has poission distribution with lambda=12
dpois(15,12)
